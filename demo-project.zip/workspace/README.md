
    ,-----.,--.                  ,--. ,---.   ,--.,------.  ,------.
    '  .--./|  | ,---. ,--.,--. ,-|  || o   \  |  ||  .-.  \ |  .---'
    |  |    |  || .-. ||  ||  |' .-. |`..'  |  |  ||  |  \  :|  `--, 
    '  '--'\|  |' '-' ''  ''  '\ `-' | .'  /   |  ||  '--'  /|  `---.
     `-----'`--' `---'  `----'  `---'  `--'    `--'`-------' `------'
    ----------------------------------------------------------------- 


Hi there! Welcome to Cloud9!

To get you started, we have created a few example applications.

1) Choose the application that you want to run by selecting a language folder

2) Open the file within the folder

3) Follow the run instructions in the file's comments
    
And that's all there is to it! Just have fun. Go ahead and edit the code, 
or add new files. It's all up to you! 

Happy coding!
The Cloud9 team

P.S. Oh, one more thing: to start a new project, hop on over to your 
dashboard (from your profile picture at the top right choose "Dashboard") 
and hit the button labelled "Create New Workspace."


## Support & Documentation

Visit http://docs.c9.io for support, or to learn more about using Cloud9. 
To watch some training videos, visit http://www.youtube.com/user/c9ide

## About this demo

We provide this demo workspace in order for you to experience the power of Cloud9. 
It contains sample projects for Node.js, PHP, Python, Ruby, and HTML5.
