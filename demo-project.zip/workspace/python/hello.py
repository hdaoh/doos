# this is the simplest python program

print ("Hello world from Cloud9!")

# click the 'Run' button at the top to start this application
